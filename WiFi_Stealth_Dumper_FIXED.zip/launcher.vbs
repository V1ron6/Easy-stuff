Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "wifi_backup.bat", 0, False
